import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  authObservable: BehaviorSubject<string> = new BehaviorSubject('');
  constructor(private httpClient: HttpClient) {}

  registerUser(data: any): Observable<any> {
    return this.httpClient.post('/api/signup', data);
  }
  loginUser(data: any): Observable<any> {
    console.log('from loginUser() of authService');
    return this.httpClient.post('/api/login', data);
  }
  loadUser(): Observable<any> {
    return this.httpClient.get('/api/');
  }
}
