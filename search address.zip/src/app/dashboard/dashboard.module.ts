import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';

import { HttpClientModule } from '@angular/common/http';
import { CoreModule } from '../core/core.module';
import { AuthService } from '../auth/services/auth.service';
import { httpInterceptorProviders } from '../core/interceptors';

import { DashboardActionsComponent } from './components/dashboard-actions/dashboard-actions.component';

@NgModule({
  declarations: [DashboardComponent, DashboardActionsComponent],
  providers: [httpInterceptorProviders, AuthService],
  imports: [CommonModule, DashboardRoutingModule, HttpClientModule, CoreModule],
})
export class DashboardModule {}
