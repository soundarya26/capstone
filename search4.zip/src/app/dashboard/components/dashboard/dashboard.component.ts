// import { stringify } from '@angular/compiler/src/util';
// import { Component, OnInit } from '@angular/core';
// import { Register } from 'src/app/auth/models/register';
// import { AuthService } from 'src/app/auth/services/auth.service';

// @Component({
//   selector: 'app-dashboard',
//   templateUrl: './dashboard.component.html',
//   styleUrls: ['./dashboard.component.css'],
// })
// export class DashboardComponent implements OnInit {
//   register: Register;

//   constructor() {}

//   ngOnInit(): void {}
// }
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MapService } from '../../services/map.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  searchQuery = '';
  addresses = [];
  selectedAddress: any;

  constructor(private router: Router, private mapService: MapService) {}
  onchange() {
    if (this.searchQuery.trim() && this.searchQuery.length > 3) {
      const addres = this.searchQuery;
      this.mapService.getAddress(addres).subscribe((res: any) => {
        console.log({ res });
        if (res) {
          this.addresses = res.copResults;
        }
      });
    }
    if (!this.searchQuery) {
      this.addresses = [];
    }
  }
  selectAddress(address: any) {
    this.selectedAddress = address;
    this.searchQuery = address.formattedAddress;
    this.addresses = [];
  }
  saveAddress() {
    console.log(this.selectedAddress);
  }

  ngOnInit(): void {}
}
