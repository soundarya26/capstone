import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class MapService {
  private authURL =
    '/api/security/oauth/token?grant_type=client_credentials&client_id=33OkryzDZsIT49ZXY1ZrYByj6gWIjKKFaCAkZM64jn5ihwKdDEScZx5KNo2cSP9MJ26tCvtQQnjQnTeuAFQ0br5B2_CONUQRWkdjAI2IKeR3eteQJz2MIA==&client_secret=lrFxI-iSEg9Pel8MHjkr7xv635VHVQkhAvYpNXpu3Pcf_5bqUs_qvjCqagZr3JQdytYZXGTWKCuTsHJlfgVwDSU5Qa_n66IUf_fvZS6Mtv4LXnCxqVwKd_ApfXpm6Rfs';
  private mapToken: string = '';
  private addressUrl = '/api/places/geocode';

  constructor(private http: HttpClient) {
    this.getToken();
  }
  getToken() {
    this.http.post(this.authURL, {}).subscribe((res: any) => {
      console.log(res);
      this.mapToken = res.access_token;
      console.log(this.mapToken);
    });
  }
  getAddress(address: string) {
    const tempUrl = this.addressUrl + '?itemCount=5&address=' + address;
    console.log({ tempUrl });
    return this.http.get(tempUrl, {
      headers: {
        Authorization: 'Bearer ' + this.mapToken,
      },
    });
  }
}
