import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Address } from '../../models/address';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css'],
})
export class AddressComponent implements OnInit {
  address: Address = new Address();

  constructor(private authService: AuthService, private router: Router) {}

  addressSubmit() {
    console.log(JSON.stringify(this.address));

    const newUser: any = {
      houseNumber: this.address.houseNumber,
      houseName: this.address.houseName,
      poi: this.address.poi,
      street: this.address.street,
      subSubLocality: this.address.subSubLocality,
      subLocality: this.address.subLocality,
      locality: this.address.locality,
      village: this.address.village,
      subDistrict: this.address.subDistrict,
      district: this.address.district,
      city: this.address.city,
      state: this.address.state,
      pincode: this.address.pincode,
      formattedAddress: this.address.formattedAddress,
      eLoc: this.address.eLoc,
      geocodeLevel: this.address.geocodeLevel,
      confidenceScore: this.address.confidenceScore,
    };
    this.authService.addAddress(newUser).subscribe((res) => {
      console.log(JSON.stringify(res));
      this.router.navigate(['/dashboard']);
      this.authService = res;
    });
    (err) => {};
  }

  ngOnInit(): void {}
}
