package com.tavant.address.security.services;

import java.io.IOException;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.tavant.address.Address;
import com.tavant.address.helper.csvfieldreader;
import com.tavant.address.models.FileDB;
import com.tavant.address.models.Response;
import com.tavant.address.repository.FileDBRepository;
@Service
public class FileStorageService {
  @Autowired
  FileDBRepository repository;
boolean validate = true;
  public void save(MultipartFile file) {
    try {
    	
      List<FileDB> filedbs = csvfieldreader.csvToTutorials(file.getInputStream());
      int c = filedbs.size();
      for(int i=0;i<c;i++)
      {
    	  Validate(filedbs.get(i));
    	  if(validate==false)
    		  break;
      }
      if(validate==true)
      {
      repository.saveAll(filedbs);}
    } catch (IOException e) {
      throw new RuntimeException("fail to store csv data: " + e.getMessage());
    }
  }
  
  public void Validate(FileDB filedb) {
	  String var= String.format("http://apis.mapmyindia.com/advancedmaps/v1/c14cow8nltk5a55bdouxqawk98ab2ejd/place_detail?place_id=%s",filedb.getEloc());
	  RestTemplate rest = new RestTemplate();
	  Response response = rest.getForObject(var, Response.class);
	  if(response.getResponseCode()==200 && response.getResults().size()>0) {
		  repository.save(filedb);
	  }
	  else
	  {
		  System.out.println(response.getResponseCode());
		  validate=false;
	  }
  }

  public Stream<FileDB> getAllTutorials() {
    return repository.findAll().stream();
  }
}