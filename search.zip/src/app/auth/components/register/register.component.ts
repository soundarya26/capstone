import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/core/services/alert.service';
import { Register } from '../../models/register';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();

  constructor(
    private authService: AuthService,
    private router: Router,
    private alertService: AlertService
  ) {}

  registerSubmit() {
    console.log(JSON.stringify(this.register));

    const newUser: any = {
      username: this.register.username,
      email: this.register.email,
      password: this.register.password,
    };

    this.authService.registerUser(newUser).subscribe(
      (res) => {
        console.log('User registered successfully');
        this.router.navigate(['/dashboard']);
        console.log(JSON.stringify(res)); //it generates token
        localStorage.setItem('token', res.token);
        this.alertService.setAlert({
          alertType: 'success',
          message: 'register Success',
        });
      },
      (err) => {
        if (this.register.username == null) {
          this.alertService.setAlert({
            alertType: 'danger',
            message: 'Name should not be null',
          });
        } else if (this.register.email == null) {
          this.alertService.setAlert({
            alertType: 'danger',
            message: 'Email should not be null',
          });
        } else if (this.register.password != this.register.password2) {
          this.alertService.setAlert({
            alertType: 'danger',
            message: 'password mismatch',
          });
        } else {
          console.log(err);
        }
      }
    );
  }
  ngOnInit(): void {}
}
