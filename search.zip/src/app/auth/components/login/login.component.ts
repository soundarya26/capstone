import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/core/services/alert.service';
import { Login } from '../../models/login';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login: Login = new Login();

  constructor(
    private authService: AuthService,
    private router: Router,
    private alertService: AlertService
  ) {}

  loginSubmit() {
    console.log(JSON.stringify(this.login));

    const newUser: any = {
      username: this.login.username,
      password: this.login.password,
    };

    this.authService.loginUser(newUser).subscribe(
      (res) => {
        console.log('User Logged In successfully');
        this.router.navigate(['/dashboard']);

        this.alertService.setAlert({
          alertType: 'success',
          message: 'Login Success',
        });
        let a = res.headers.get('Authorization');
        a = a.substring(7, a.length() - 1);
        console.log(JSON.stringify(res)); //it generates a token
        localStorage.setItem('token', a.token); //stores a token
      },
      (err) => {
        if (this.login.username == null) {
          this.alertService.setAlert({
            alertType: 'danger',
            message: 'Email should not be null',
          });
        }
        if (this.login.password == null) {
          this.alertService.setAlert({
            alertType: 'danger',
            message: 'Password should be provided',
          });
        }
      }
    );
  }

  ngOnInit(): void {}
}
