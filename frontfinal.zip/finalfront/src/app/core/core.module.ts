import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreRoutingModule } from './core-routing.module';

import { httpInterceptorProviders } from './interceptors';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LandingComponent } from './components/landing/landing.component';
import { FooterComponent } from './components/footer/footer.component';

import { AlertService } from './services/alert.service';
import { AuthService } from '../auth/services/auth.service';
import { AlertComponent } from './components/alert/alert.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    NavbarComponent,
    LandingComponent,
    FooterComponent,
    AlertComponent,
  ],
  imports: [CommonModule, HttpClientModule, CoreRoutingModule],
  providers: [AlertService, httpInterceptorProviders, AuthService],
  exports: [NavbarComponent, LandingComponent, FooterComponent, AlertComponent],
})
export class CoreModule {}
