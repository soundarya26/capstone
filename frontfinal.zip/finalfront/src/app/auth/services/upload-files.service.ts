import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpRequest,
  HttpHeaders,
  HttpEvent,
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UploadFileService {
  private baseUrl = 'http://localhost:9000';

  constructor(private http: HttpClient) {}

  upload(file: File): Observable<HttpEvent<any>> {
    const formData: FormData = new FormData();

    formData.append('file', file);

    const req = new HttpRequest(
      'POST',
      `http://localhost:9000/api/csv/upload`,
      formData,
      {
        reportProgress: true,
        responseType: 'json',
      }
    );

    return this.http.request(req);
  }
  // upload(file: File): Observable<any> {

  //   console.log('from add address of auth service');
  //   return this.http.post(`http://localhost:9000/api/csv/upload`, file, {
  //     reportProgress: true,
  //     responseType: 'multipart/form-data',
  //   });
  // }
  // getFiles(): Observable<any> {
  //   return this.http.get(`/files`);
  // }
}
// export class UploadFileService {
//   private baseUrl = 'http://localhost:9000';

//   constructor(private http: HttpClient) {}

//   upload(file: File): Observable<HttpEvent<any>> {
//     const formData: FormData = new FormData();

//     formData.append('file', file);
// Headers: new HttpHeaders({
//   Accept: 'text/csv',
// });
//   const req = new HttpRequest(
//     'POST',
//     `http://localhost:9000/api/csv/upload`,

//     formData,
//     {
//       reportProgress: true,
//       responseType: 'json',
//     }
//   );

//   return this.http.request(req);
// }

// getFiles(): Observable<any> {
//   return this.http.get(`${this.baseUrl}/files`);
// }
// }
