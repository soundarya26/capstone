// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class AddressService {

//   constructor() { }
// }
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AddressService {
  constructor(private httpClient: HttpClient) {}
  addAddress(data: any): Observable<any> {
    console.log('from loginUser() of authServcie');
    return this.httpClient.post('/api/address/add', data);
  }
  getAddress(): Observable<any> {
    return this.httpClient.get('/api/address/all');
  }
}
