// import { stringify } from '@angular/compiler/src/util';
// import { Component, OnInit } from '@angular/core';
// import { Register } from 'src/app/auth/models/register';
// import { AuthService } from 'src/app/auth/services/auth.service';

// @Component({
//   selector: 'app-dashboard',
//   templateUrl: './dashboard.component.html',
//   styleUrls: ['./dashboard.component.css'],
// })
// export class DashboardComponent implements OnInit {
//   register: Register;

//   constructor() {}

//   ngOnInit(): void {}
// }
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Address } from '../../models/address';
import { AddressService } from '../../services/address.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  address: Address;

  constructor(private addressService: AddressService, private router: Router) {}
  addressSubmit() {
    console.log(JSON.stringify(this.address));

    const newUser: any = {
      houseNumber: this.address.houseNumber,
      houseName: this.address.houseName,
      poi: this.address.poi,
      street: this.address.street,
      subSubLocality: this.address.subSubLocality,
      subLocality: this.address.subLocality,
      locality: this.address.locality,
      village: this.address.village,
      subDistrict: this.address.subDistrict,
      district: this.address.district,
      city: this.address.city,
      state: this.address.state,
      pincode: this.address.pincode,
      formattedAddress: this.address.formattedAddress,
      eLoc: this.address.eLoc,
      geocodeLevel: this.address.geocodeLevel,
      confidenceScore: this.address.confidenceScore,
    };
    this.addressService.addAddress(newUser).subscribe((res) => {
      console.log(JSON.stringify(res));
      this.addressService = res;
    });
    (err) => {};
  }

  ngOnInit(): void {}
}
