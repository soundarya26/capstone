package com.tavant.authservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tavant.authservice.model.Login;
import com.tavant.authservice.model.Register;

@Repository
public interface LoginRepository extends JpaRepository<Login, String>  {

}
