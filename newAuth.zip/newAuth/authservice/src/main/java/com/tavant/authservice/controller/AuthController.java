package com.tavant.authservice.controller;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.authservice.exception.AppException;
import com.tavant.authservice.model.Login;
import com.tavant.authservice.model.Register;

import com.tavant.authservice.payloads.ApiResponse;
import com.tavant.authservice.payloads.SignUpRequest;
import com.tavant.authservice.repository.LoginRepository;
import com.tavant.authservice.repository.RegisterRepository;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class AuthController {

	@Autowired
	RegisterRepository registerRepository;
	@Autowired
	LoginRepository loginRepository;

	@Autowired
	BCryptPasswordEncoder passwordEncoder; 
	
	@Autowired
	Environment environment;
	
	@RequestMapping("/")
	public String home() {
		return "hello from auth app"+environment.getProperty("server.port");
		
	}
	  @GetMapping("/{user}")
	    public ResponseEntity<?> getUserById(@PathVariable("user") Integer id) {
	    Optional<Register> auth = registerRepository.findById(id);if (auth.isPresent()) {
	    return ResponseEntity.ok(auth.get());
	    } else {
	    ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Not Found");
	    }
	    return null;
	    }
//	  @PostMapping("/login")
//	  public ResponseEntity<?> loginUser(@Valid @RequestBody SignUpRequest loginRequest) { 
//		  Login login=new Login();
//		  login.setUsername(loginRequest.getUsername());
//		  login.setPassword(login.getPassword());
//		  login =loginRepository.save(login);
//		  return ResponseEntity.status(HttpStatus.OK)
//	                .body(login);
//		  
//	  }
			
	  
	
	@PostMapping("/signup")
	
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest) { 
		
		if (registerRepository.existsByUsername(signUpRequest.getUsername())) {
			return new ResponseEntity(new ApiResponse(false, "Username is already taken!"), HttpStatus.BAD_REQUEST);
		}

		if (registerRepository.existsByEmail(signUpRequest.getEmail())) {
			return new ResponseEntity(new ApiResponse(false, "Email Address already in use!"), HttpStatus.BAD_REQUEST);
		}

		// Creating register's account
		Register register = new Register();

		register.setUsername(signUpRequest.getUsername());
		register.setEmail(signUpRequest.getEmail());
	    
		register.setPassword(signUpRequest.getPassword());
	
        register.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));

//		Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
//				.orElseThrow(() -> new AppException("User Role not set."));

//        register.setRoles(Collections.singleton(userRole));

		register=registerRepository.save(register);

		return ResponseEntity.status(HttpStatus.OK)
                .body(register);

		
	}
	
	@GetMapping("/all")
	
	public List<Register> getUser() {
		List<Register> reg = registerRepository.findAll();
		if(reg.size()==0) {
			return null;
		}
		else {
			return reg;
		}
		
	}
	
}
