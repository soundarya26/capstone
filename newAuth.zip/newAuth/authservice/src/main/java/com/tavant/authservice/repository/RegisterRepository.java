package com.tavant.authservice.repository;

import java.util.Optional;

//import ca.concordia.soen6841.auth.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tavant.authservice.model.Register;

@Repository
public interface RegisterRepository extends JpaRepository<Register, Integer> {
    Optional<Register> findByEmail(String email);

    Optional<Register> findByUsernameOrEmail(String username, String email);

    Optional<Register> findByUsername(String username);

    Boolean existsByUsername(String name);

    Boolean existsByEmail(String email);
}
