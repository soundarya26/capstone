export class Register {
  username: String;
  email: String;
  password: String;
  password2: String;
}
